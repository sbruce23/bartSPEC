ChangeRule <-
function(tree,treeI,YDat,Nnode,x,VarType,RuleNum,Rulemat,Top_idx,param_random,nbeta,nseg_time_temp,nus,Gs,s,p,darton,opt)
  {
    
    ## Select idx to change
    dr_nog_node=DrNogNodeC(treeI,Top_idx,tree)
    idx=dr_nog_node$idx_select
    
    
    
    if(darton){
      
      if(p<=(opt$nwarmup/2))
      {
        
        VarI = DrPriVar(tree,treeI,idx) # draw variable
        cat("regular var",VarI,"\n")
        
      }else{
        
        VarI = DrPriVar_Dirichlet(s) # draw variable
      }
      
    }else{
      
      VarI = DrPriVar(tree,treeI,idx)
    }
    
    
    if(!(tree[[treeI]][[paste("node",idx,sep = "")]]$VarAvail[VarI]==1))
    {
      done=0
      
      list(tree=tree,alpha=-1,done=done,Nnode=Nnode,Var=VarI,idx=idx,tau=tree[[treeI]][[paste("node",idx,sep = "")]]$tau,g=tree[[treeI]][[paste("node",idx,sep = "")]]$g)
      
    }else{
      
      
      rule=SplitRule(tree,treeI,idx,x,VarI,VarType,RuleNum,Rulemat)
      
      
      
      PDxl=1-PGrow(tree,treeI,idx*2)
      PDxr=1-PGrow(tree,treeI,(idx*2+1))
      PDxp=PGrow(tree,treeI,idx)
      
      ##### copy old rule
      
      var_copy=tree[[treeI]][[paste("node",idx,sep = "")]]$Var
      rule_copy=tree[[treeI]][[paste("node",idx,sep = "")]]$Rule
      
      tau_copyl=tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau
      tau_copyr=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau
      
      g_copyl=tree[[treeI]][[paste("node",2*idx,sep = "")]]$g
      g_copyr=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g
      
      beta_copyl=tree[[treeI]][[paste("node",2*idx,sep = "")]]$beta
      beta_copyr=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$beta
      
      fhat_copyl=tree[[treeI]][[paste("node",2*idx,sep = "")]]$fhat
      fhat_copyr=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$fhat
      
      
      ### CURRENT 
      
      loglike_curr=0
      log_beta_curr=0
      log_beta_prior_curr=0
      
      nfreq <- floor(nseg_time_temp/2)
      fhat_curr=matrix(0,nfreq+1,2)
      
      jj=0
      for (k in (2*idx):(2*idx+1))
      {
        jj=jj+1
        postbeta_6=postbeta(tree,treeI,k,nseg_time_temp,tree[[treeI]][[paste("node",k,sep = "")]]$tau,YDat,nbeta,opt)
        log_beta_curr=log_beta_curr+dmvnorm(tree[[treeI]][[paste("node",k,sep = "")]]$beta,postbeta_6$beta_mean,0.5*(postbeta_6$beta_var+t(postbeta_6$beta_var)),log = T)
        log_beta_prior_curr=log_beta_prior_curr+dmvnorm(tree[[treeI]][[paste("node",k,sep = "")]]$beta,matrix(0,nbeta,1),diag(c(opt$sigmasqalpha, tree[[treeI]][[paste("node",k,sep = "")]]$tau*matrix(1,opt$nbasis,1))),log = T)
        
        # Loglikelihood at current values
        fhat_curr[,jj]=postbeta_6$nu_mat%*%matrix(tree[[treeI]][[paste("node",k,sep = "")]]$beta,nbeta,1)
        log_curr_spec_dens=whittle_like(postbeta_6$y,fhat_curr[,jj],nseg_time_temp)
        loglike_curr=loglike_curr+log_curr_spec_dens
        
      }
      
      # Calculating log proposal density at current values
      log_proposal_curr=log_beta_curr
      
      # Calculating priors at current values
      log_prior_curr=log_beta_prior_curr
      
      # Evaluating Target density at current values(taking duplicates into consideration)
      log_target_curr=loglike_curr+log_prior_curr
      
      
      ##### Set new variable and order rule
      tree[[treeI]][[paste("node",idx,sep = "")]]$Var=VarI
      tree[[treeI]][[paste("node",idx,sep = "")]]$Rule=rule$Rule
      
      ####### kill original children
      tree=KillChildren(tree,treeI,idx)
      
      #### create new children
      #tree=SpawnChildrenC(tree,treeI,idx,rule$LeftEx,rule$RightEx,x,VarType,RuleNum,Rulemat) # create children
      SpawnChildrenC(treeI,idx,rule$LeftEx,rule$RightEx,VarI, rule$Rule, tree, VarType,x,RuleNum,Rulemat) # create children
      
      tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau = tau_copyl
      tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau = tau_copyr
      
      tree[[treeI]][[paste("node",2*idx,sep = "")]]$g=g_copyl
      tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g=g_copyr
      
      
      ###### PROPOSAL
      # Evaluating the Likelihood, Proposal and Prior Densities at the Proposed values
      loglike_prop=0
      log_beta_prop=0
      log_beta_prior_prop=0
      
      # Computing mean and variances for beta proposals
      
      nfreq <- floor(nseg_time_temp/2)
      fhat_prop=matrix(0,nfreq+1,2)
      beta_prop=matrix(0,nbeta,2)
      
      jj=0
      for (k in (2*idx):(2*idx+1))
      {
        jj=jj+1
        
        postbeta_7=postbeta(tree,treeI,k,nseg_time_temp,tree[[treeI]][[paste("node",k,sep = "")]]$tau,YDat,nbeta,opt)
        beta_prop[,jj]=rmvnorm(1,postbeta_7$beta_mean,0.5*(postbeta_7$beta_var+t(postbeta_7$beta_var))) # Drawing a new value of beta
        # Beta prop
        log_beta_prop=log_beta_prop+dmvnorm(beta_prop[,jj],postbeta_7$beta_mean,0.5*(postbeta_7$beta_var+t(postbeta_7$beta_var)),log = T)
        # Beta prior
        log_beta_prior_prop=log_beta_prior_prop+dmvnorm(beta_prop[,jj],matrix(0,nbeta,1),diag(c(opt$sigmasqalpha, tree[[treeI]][[paste("node",k,sep = "")]]$tau*matrix(1,opt$nbasis,1))), log = T)
        
        # Loglikelihood  at proposed values
        fhat_prop[,jj]=postbeta_7$nu_mat%*%matrix(beta_prop[,jj],nbeta,1)
        log_prop_spec_dens=whittle_like(postbeta_7$y,fhat_prop[,jj],nseg_time_temp)
        loglike_prop=loglike_prop+log_prop_spec_dens
        
      }
      
      # Calculating log proposal density at proposed values
      log_proposal_prop=log_beta_prop
      
      # Calculating log prior density at proposed values
      log_prior_prop=log_beta_prior_prop
      
      # Evaluating Target density at proposed values(taking duplicates into consideration)
      log_target_prop=loglike_prop+log_prior_prop
      
      PDyl=1-PGrow(tree,treeI,idx*2)
      PDyr=1-PGrow(tree,treeI,idx*2+1)
      PDyp=PGrow(tree,treeI,idx)
      
      alpha1=(PDyl*PDyr*PDyp)/(PDxl*PDxr*PDxp)
      alpha=min(1,exp(log_target_prop-log_target_curr+log_proposal_curr-log_proposal_prop)*alpha1)
      
      r3=runif(1)
      if(r3<alpha)
      {
        done=1
        
        jj=0
        for (k in (2*idx):(2*idx+1))
        {
          
          jj=jj+1
          tree[[treeI]][[paste("node",k,sep = "")]]$beta= beta_prop[,jj]
          tree[[treeI]][[paste("node",k,sep = "")]]$fhat= fhat_prop[,jj]
          
        }
        
      }else
      {
        done=0
        
        tree[[treeI]][[paste("node",idx,sep = "")]]$Var= var_copy
        tree[[treeI]][[paste("node",idx,sep = "")]]$Rule= rule_copy
        
        rule_back=SplitRule_change(tree,treeI,idx,var_copy,x,VarType,Rulemat)
        
        ####### kill original children
        tree=KillChildren(tree,treeI,idx)
        
        
        #### create new children
        #tree=SpawnChildrenC(tree,treeI,idx,rule_back$LeftEx,rule_back$RightEx,x,VarType,RuleNum,Rulemat) # create children
        SpawnChildrenC(treeI,idx,rule_back$LeftEx,rule_back$RightEx,var_copy, rule_copy, tree, VarType, x, RuleNum,Rulemat) # create children
        
        
        ### update VarAvail
        update=DrBotNodeC(treeI,Top_idx,tree,VarType,x,Rulemat)
        
        tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau= tau_copyl
        tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau= tau_copyr
        
        
        tree[[treeI]][[paste("node",2*idx,sep = "")]]$g=g_copyl
        tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g= g_copyr
        
        
        beta_curr=matrix(0,nbeta,2)
        fhat_re_curr=matrix(0,nfreq+1,2)
        
        jj=0
        for (k in (2*idx):(2*idx+1))
        {
          jj=jj+1
          
          postbeta_8=postbeta(tree,treeI,k,nseg_time_temp,tree[[treeI]][[paste("node",k,sep = "")]]$tau,YDat,nbeta,opt)
          beta_curr[,jj]=rmvnorm(1,postbeta_8$beta_mean,0.5*(postbeta_8$beta_var+t(postbeta_8$beta_var))) # Drawing a new value of beta
          fhat_re_curr[,jj]=postbeta_8$nu_mat%*%matrix(beta_curr[,jj],nbeta,1)
          
          ## draw new beta and fhat
          tree[[treeI]][[paste("node",k,sep = "")]]$beta= beta_curr[,jj]
          tree[[treeI]][[paste("node",k,sep = "")]]$fhat= fhat_re_curr[,jj]
          
          
        }
        
        
      }
      
      list(tree=tree,alpha=alpha,done=done,Var=VarI,cutpoint=rule$Rule,idx=idx,Nnode=Nnode,taul=tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau,taur=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau,gl=tree[[treeI]][[paste("node",2*idx,sep = "")]]$g,gr=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g)
      
    } 
    
  }
