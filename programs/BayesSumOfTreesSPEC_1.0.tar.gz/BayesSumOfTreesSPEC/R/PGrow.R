PGrow <-
function(tree,treeI,idx)
  {
    alpha=0.95
    beta=2
    SumGoodVar=sum(tree[[treeI]][[paste("node",idx,sep = "")]]$VarAvail)
    if(SumGoodVar)
    {
      nobs=length(tree[[treeI]][[paste("node",idx,sep = "")]]$DataList)
      if(nobs<3) {
        
        return (.001*alpha/((1.0+Depth(tree,treeI,idx))^beta))
        
      }else {
        
        return (alpha/((1.0+Depth(tree,treeI,idx))^beta))
      }
    } else {
      return (0)
    }
  }
