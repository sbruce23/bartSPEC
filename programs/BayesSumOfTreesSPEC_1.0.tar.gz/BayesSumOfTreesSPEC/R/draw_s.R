draw_s <-
function(tree,Top_idx,theta,Ntree,NumX)
  {
    
    var_list=c()
    theta_post=c()
    for(i in 1:Ntree)
    {
      var_list=append(var_list,TopPathC(i,Top_idx,tree)$varidx)
    }
    
    
    for (z in 1:NumX)
    {
      if(any(names(table(var_list))==z))
      {
        index=which(names(table(var_list))==z)
        theta_post[z]=theta/NumX+table(var_list)[index]
      }else
      {
        theta_post[z]=theta/NumX
      }
      
    }
    
    # # Dirichlet random number
    # temp_gamma=c()
    # for(k in 1:length(theta_post))
    # {
    #   temp_gamma[k]=log(rgamma(1,shape=theta_post[k]+1,rate=1))+log(runif(1)/theta_post[k])
    # }
    # 
    # lse=log(sum(exp(temp_gamma)))
    # log_s=temp_gamma-lse
    # 
    # s=exp(log_s)
    
    
    s=rdirichlet(1, theta_post)
    
    log_s=1
    
    list(s=s,theta_post=theta_post,log_s=log_s)
    
  }
