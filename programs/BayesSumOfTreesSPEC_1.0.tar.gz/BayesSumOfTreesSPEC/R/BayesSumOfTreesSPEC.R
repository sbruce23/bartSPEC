BayesSumOfTreesSPEC <-
function(x_t,x,Ntime,NumObs,Ntree,NumX,VarType,numcut,nus,Gs,param_random,theta,darton,opt)
  {
    
    nbeta=opt$nbasis+1
    nb_alpha=nbeta
    
    ### build tree 
    tree=list()
    for(i in 1:Ntree)
    {
      tree[[i]]=list()
      tree[[i]]$node1=list("Top"=1,"Bot"=1,"Nog"=0,"Parent"=0,"LeftC"=2,"RightC"=3,"Var"=0,"Rule"=0,"VarAvail"=rep(1,NumX),"DataList"=seq(1:NumObs),"tau"=0,"g"=0,"beta"=0)
    }
    
    
    #### Set Rule information
    RuleNum=numcut
    
    Rulemat=list()
    for (i in 1:NumX)
    {
      if(VarType[i]=="CAT")
      {
        
        Rulemat[[i]]=levels(as.factor(x[,i]))
        
      }else{
        max=max(x[,i])
        min=min(x[,i])
        xinc=(max-min)/(RuleNum[i]+1)
        Rulemat[[i]]=seq(min+xinc,min+RuleNum[i]*xinc,by=xinc)
        
      }
    }
    
    ### periodograms for each obervation 
    ### time series information
    nseg_time_temp=Ntime
    Y=matrix(0,nseg_time_temp,NumObs)
    YDat=matrix(0,nseg_time_temp,NumObs)
    Nnode=rep(0,Ntree)
    
    for(j in 1:NumObs)
    {
      Y[,j] = log(abs(fft(x_t[,j]))^2/nseg_time_temp)
      YDat[,j]=Y[,j]
    }
    
    ### initial data for the Number of node of each tree
    for (i in 1:Ntree)
    {
      Nnode[i]=length(tree[[i]])
    }
    
    ### initialize tau value for the ith tree
    for(i in 1:Ntree)
    {
      tree[[i]]$node1$tau=1
    }
    
    ######  initialize g value for the ith tree
    
    
    for(i in 1:Ntree)
    {
      tree[[i]]$node1$g=1
    }
    
    ######  initialize beta value for the ith tree
    for(i in 1:Ntree)
    {
      
      postbeta_curr=postbeta(tree,i,1,nseg_time_temp,tree[[i]]$node1$tau,Y/Ntree,nbeta,opt)
      tree[[i]]$node1$beta=rmvnorm(1,postbeta_curr$beta_mean,0.5*(postbeta_curr$beta_var+t(postbeta_curr$beta_var)))
    }
    
    ### Initialize data information
    ###### method2 (initialize the fitted value for each tree)
    mtotalfit=matrix(0,nseg_time_temp,NumObs)
    mtrainFits=array(0,c(Ntree,nseg_time_temp,NumObs))
    
    postbeta_fit_average=postbeta(tree,1,1,nseg_time_temp,tree[[1]]$node1$tau,Y/Ntree,nbeta,opt)
    beta_prop_average=rmvnorm(1,postbeta_fit_average$beta_mean,0.5*(postbeta_fit_average$beta_var+t(postbeta_fit_average$beta_var))) # Drawing a new value of beta
    fhat_fit_average=postbeta_fit_average$nu_mat%*%matrix(beta_prop_average,nbeta,1)
    
    if(nseg_time_temp%%2!=0)
    {
      fhat_fit_average_complete=c(fhat_fit_average,fhat_fit_average[((nseg_time_temp/2)+1):2,1])  # only for even time
      
    }else{
      fhat_fit_average_complete=c(fhat_fit_average,fhat_fit_average[(nseg_time_temp/2):2,1])  # only for even time
      
    }
    
    mtotalfit=repmat(as.matrix(fhat_fit_average_complete*Ntree),1,NumObs)
    for(i in 1:Ntree)
    {
      mtrainFits[i,,]=mtotalfit/Ntree
    }
    
    ########### MCMC Sampler
    nloop=opt$nloop
    
    ### Dart
    s=matrix(0,nloop, NumX)
    posttheta=matrix(0,nloop, NumX)
    #s[1:(opt$nwarmup/2+1),]=repmat(rdirichlet(1,rep(theta/NumX,NumX)),(opt$nwarmup/2+1),1)
    s[1:(opt$nwarmup/2+1),]=theta/NumX
    
    result=matrix(list(),nloop,Ntree)
    aaindex=matrix(list(),nloop,Ntree)
    Num_node=matrix(0,nloop,Ntree)
    Num_bottom=matrix(0,nloop,Ntree)
    tau_sum=matrix(0,nloop,Ntree)
    g_sum=matrix(0,nloop,Ntree)
    beta_sum=array(0,c(nloop,Ntree,nbeta))
    Num_depth=matrix(0,nloop,Ntree)
    ttrree_list=matrix(list(),nloop,Ntree)
    cut_point=matrix(list(),nloop,NumX)
    tree_store=matrix(list(),nloop,Ntree)
    fhat_log=array(0,c(nloop,nseg_time_temp,NumObs))
    
    
    
    Top_idx=1
    time=matrix(0,nloop,Ntree)
    start=matrix(0,nloop,Ntree)
    end=matrix(0,nloop,Ntree)
    
    for(p in 1:nloop)
    {
      
      ### update s for dart
      if(p>(opt$nwarmup/2) & darton)
      {
        draws=draw_s(tree,Top_idx,theta,Ntree,NumX)
        s[p,]=draws$s
        posttheta[p,]=draws$theta_post
        
      }
      
      
      for(i in 1:Ntree)
      {
        start[p,i]=Sys.time()
        cat("ite p is",p,"\n")
        cat("tree is",i,"\n")
        
        # get residual for the jth tree
        for (j in 1:NumObs)
        {
          #method1
          YDat[,j]=Y[,j]-(mtotalfit[,j]-mtrainFits[i,,j])
        }
        
        
        result[[p,i]]=Metrop(tree,i,YDat,Nnode[i],x,VarType,RuleNum,Rulemat,Top_idx,param_random,nbeta,nseg_time_temp,nus,Gs,s[p,],p,darton,opt)
        tree=result[[p,i]]$tree
        Nnode[i]=result[[p,i]]$Nnode
        Num_node[p,i]=result[[p,i]]$Nnode
        
        
        ## update tau & g
        bot_index=BotIndex_noconditionC(i,Top_idx,tree)
        
        
        for(ss in 1:length(bot_index))
        {
          
          g_a=(nus + 1)/2
          g_b=(nus)/tree[[i]][[paste("node",bot_index[ss],sep = "")]]$tau + 1/(Gs^2)
          tree[[i]][[paste("node",bot_index[ss],sep = "")]]$g = 1/rgamma(1,g_a,scale=1/g_b)
          
          tau_a=(nb_alpha - 1 + nus)/2
          tau_b=sum(tree[[i]][[paste("node",bot_index[ss],sep = "")]]$beta[2:nbeta]^2)/(2)+nus/tree[[i]][[paste("node",bot_index[ss],sep = "")]]$g
          tree[[i]][[paste("node",bot_index[ss],sep = "")]]$tau = 1/rgamma(1,tau_a,rate=tau_b)
          
        }
        
        # calculate mfit
        for (j in 1:NumObs)
        {
          
          idx=FindNodeC(j,1,i,tree,x,VarType,RuleNum,Rulemat) # from the top node of the ith tree, find the bottom idx for jth obs
          
          # method1
          if(nseg_time_temp%%2!=0)
          {
            mfit=c(tree[[i]][[paste("node",idx,sep = "")]]$fhat,tree[[i]][[paste("node",idx,sep = "")]]$fhat[((Ntime/2)+1):2])
            
          }else{
            
            mfit=c(tree[[i]][[paste("node",idx,sep = "")]]$fhat,tree[[i]][[paste("node",idx,sep = "")]]$fhat[(Ntime/2):2])
            
          }
          
          mtotalfit[,j] = mtotalfit[,j] + mfit-mtrainFits[i,,j]
          mtrainFits[i,,j]=mfit
          
        }
        
        
        # method1
        apply_sum_vecC(mtrainFits,c(Ntree,Ntime,NumObs),fhat_log,nloop,p)
        
        ##### diagnostic
        ## store tree for pth ite
        tree_store[[p,i]]=tree[[i]]
        
        ## Number of bottom nodes
        Num_bottom[p,i]=BotNumber_noconditionC(i,Top_idx,tree)
        
        
        ### Index of bottom nodes
        aaindex[[p,i]]=BotIndex_noconditionC(i,Top_idx,tree)
        
        ### Ave tau, g and beta
        aa_index=aaindex[[p,i]]
        for(ss in 1:length(aa_index))
        {
          tau_sum[p,i]=tau_sum[p,i]+tree[[i]][[paste("node",aa_index[ss],sep = "")]]$tau
          g_sum[p,i]=g_sum[p,i]+tree[[i]][[paste("node",aa_index[ss],sep = "")]]$g
          beta_sum[p,i,]=beta_sum[p,i,]+tree[[i]][[paste("node",aa_index[ss],sep = "")]]$beta
        }
        
        
        ## Death
        depth_idx=max(aa_index)
        Num_depth[p,i]=Depth(tree,i,depth_idx)
        
        
        ##### cutpoint frequency
        if(length(tree[[i]])>1)
        {
          
          bb_index=NotBotIndexC(i,Top_idx,tree)
          for(ss in 1:length(bb_index))
          {
            for(q in 1:NumX)
            {
              if(tree[[i]][[paste("node",bb_index[ss],sep = "")]]$Var==q)
              {
                cut_point[[p,q]]=append(cut_point[[p,q]],tree[[i]][[paste("node",bb_index[ss],sep = "")]]$Rule)
              }
              
            }
          }
          
        }
        
        
        ## Top_path
        ttrree_list[[p,i]]=TopPathC(i,Top_idx,tree)
        
        end[p,i]=Sys.time()
        
        time[p,i]=end[p,i]-start[p,i]
        
        
      }
      
      
      
    }
    
    
    ######## Estimated log spectrum
    nfreq <- floor(nseg_time_temp/2)
    spec_est=matrix(0,nseg_time_temp,NumObs)
    nwarmup=opt$nwarmup
    
    for(p in nwarmup:nloop)
    {
      spec_est=spec_est+fhat_log[p,,]/(nloop-nwarmup+1)
    }
    
    list(spec_est=spec_est,fhat_log=fhat_log,Y=Y,ttrree_list=ttrree_list,cut_point=cut_point,Num_depth=Num_depth,beta_sum=beta_sum,g_sum=g_sum,tau_sum=tau_sum,Num_bottom=Num_bottom,tree_store=tree_store,result=result,Num_node=Num_node,aaindex=aaindex,s=s,posttheta=posttheta,runtime=time,start=start,end=end)
    
  }
