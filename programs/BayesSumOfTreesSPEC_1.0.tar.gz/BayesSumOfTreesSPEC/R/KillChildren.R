KillChildren <-
function(tree,treeI,idx)
  {
    tree[[treeI]][[paste("node",2*idx,sep = "")]]=NULL
    tree[[treeI]][[paste("node",2*idx+1,sep = "")]]=NULL
    
    tree[[treeI]][[paste("node",idx,sep = "")]]$Bot = 1
    tree[[treeI]][[paste("node",idx,sep = "")]]$Nog = 0
    
    if(!tree[[treeI]][[paste("node",idx,sep = "")]]$Top)
    {
      idx_p=tree[[treeI]][[paste("node",idx,sep = "")]]$Parent
      if(idx==tree[[treeI]][[paste("node",idx_p,sep = "")]]$LeftC)
      {
        if(tree[[treeI]][[paste("node",idx+1,sep = "")]]$Bot)
        {
          tree[[treeI]][[paste("node",idx_p,sep = "")]]$Nog = 1
        }
      }else{
        if(tree[[treeI]][[paste("node",idx-1,sep = "")]]$Bot)
        {
          tree[[treeI]][[paste("node",idx_p,sep = "")]]$Nog = 1
        }
      }
    }
    
    return(tree)
  }
