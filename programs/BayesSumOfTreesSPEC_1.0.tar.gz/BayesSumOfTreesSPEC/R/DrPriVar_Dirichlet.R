DrPriVar_Dirichlet <-
function(s)
  {
    # stp=0
    # while(stp==0)
    # {
    #   var_select=which(rmultinom(1,1,s)==1)
    #   if(tree[[treeI]][[paste("node",idx,sep = "")]]$VarAvail[var_select]==1)
    #   {
    #     stp=1
    #     return(var_select)
    #   }
    # }
    
    var_select=which(rmultinom(1,1,s)==1)
    return(var_select)
    
  }
