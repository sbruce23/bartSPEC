postbeta <-
function(tree,treeI,idx,nseg_time_temp,tau_temp,YDat,nbeta,opt)
  {
    
    #idx is the index of one of bottom node
    
    nfreq <- floor(nseg_time_temp/2)
    freq <- (0:nfreq)/(2 * nfreq)
    
    # create set of indices for replications in jth covariate segment
    uu=tree[[treeI]][[paste("node",idx,sep = "")]]$DataList
    
    # create log periodograms for replications in ith time seg and jth cov seg
    y=matrix(0,nseg_time_temp,length(uu))
    yy=matrix(0,nfreq+1,length(uu))
    
    jj=0
    for (k in 1:length(uu)) # k is the index of observations
    {
      
      jj=jj+1
      
      y[,jj]=YDat[,uu[k]]
      yy[,jj]=y[1:(nfreq+1),jj]
      
    }
    
    # pass log periodograms into optimizer to obtain beta_mean and beta_var for normal approximation to beta posterior
    
    nu_mat=lin_basis_func(freq,nbeta) # basis function
    nn=nseg_time_temp
    ytemp=yy
    param <- rep(0, nbeta)
    
    post <- trust_RA(param, rinit = 1, rmax = 100,
                     parscale = rep(1, nbeta), iterlim = 100, fterm = sqrt(.Machine$double.eps),
                     mterm = sqrt(.Machine$double.eps), minimize = TRUE,
                     nn, nu_mat, ytemp, tau_temp, nbeta, opt$nbasis,opt$sigmasqalpha)
    
    beta_mean <- post$argument
    beta_var <-  solve(post$hessian)
    list(beta_mean = beta_mean, beta_var = beta_var, nu_mat = nu_mat,
         y = y)
    
  }
