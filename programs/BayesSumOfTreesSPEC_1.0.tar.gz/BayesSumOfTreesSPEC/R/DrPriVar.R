DrPriVar <-
function(tree,treeI,idx)
  {
    SumGoodVar=sum(tree[[treeI]][[paste("node",idx,sep = "")]]$VarAvail)  # SumGoodVar
    varpossible=floor(runif(1)*SumGoodVar)+1
    varidx=which(tree[[treeI]][[paste("node",idx,sep = "")]]$VarAvail==1)[varpossible]
    
    return(varidx)
  }
