Depth <-
function(tree,treeI,idx)
  {
    d=0
    while(!tree[[treeI]][[paste("node",idx,sep = "")]]$Top)
    {
      d=d+1
      idx=tree[[treeI]][[paste("node",idx,sep = "")]]$Parent
    }
    return(d)
  }
