whittle_like <-
function(y,fhat,nseg) {
    
    nfreq=floor(nseg/2)
    log_prop_spec_dens=0
    
    if(nseg%%2==1)
    {
      
      for (i in 1:dim(y)[2])
      {
        log_prop_spec_dens=log_prop_spec_dens-sum(fhat[2:(nfreq+1)]+exp(y[2:(nfreq+1),i]-fhat[2:(nfreq+1)]))-
          0.5*(fhat[1]+exp(y[1,i]-fhat[1]))-0.5*nfreq*log(2*pi)
        
      }
      
    }else
    {
      for (i in 1:dim(y)[2])
      {
        log_prop_spec_dens=log_prop_spec_dens-sum(fhat[2:nfreq]+exp(y[2:nfreq,i]-fhat[2:nfreq]))-
          0.5*(fhat[1]+exp(y[1,i]-fhat[1]))-0.5*(fhat[nfreq+1]+exp(y[nfreq+1,i]-fhat[nfreq+1]))-
          0.5*nfreq*log(2*pi)
      }
    }
    
    return(log_prop_spec_dens)
  }
