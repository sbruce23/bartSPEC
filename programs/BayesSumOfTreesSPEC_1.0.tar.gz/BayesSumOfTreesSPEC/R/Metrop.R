Metrop <-
function(tree,treeI,YDat,Nnode,x,VarType,RuleNum,Rulemat,Top_idx,param_random,nbeta,nseg_time_temp,nus,Gs,s,p,darton,opt)
  {
    re=list()
    r=runif(1)
    if(Nnode==1)
    {
      
      re=BirthDeath(tree,treeI,YDat,Nnode,x,VarType,RuleNum,Rulemat,Top_idx,param_random,nbeta,nseg_time_temp,nus,Gs,s,p,darton,opt)
      if(re$BD)
      {
        re$step=c("Birth")
      }else{
        re$step=c("Death")
      }
      
    }else{
      
      if(r<0.5)
      {
        
        re=BirthDeath(tree,treeI,YDat,Nnode,x,VarType,RuleNum,Rulemat,Top_idx,param_random,nbeta,nseg_time_temp,nus,Gs,s,p,darton,opt)
        if(re$BD)
        {
          re$step=c("Birth")
        }else{
          re$step=c("Death")
        }
        
      }else{
        
        re=ChangeRule(tree,treeI,YDat,Nnode,x,VarType,RuleNum,Rulemat,Top_idx,param_random,nbeta,nseg_time_temp,nus,Gs,s,p,darton,opt)
        re$step=c("Change")
      }
      
    }
    
    return(re)
  }
