BirthDeath <-
function(tree,treeI,YDat,Nnode,x,VarType,RuleNum,Rulemat,Top_idx,param_random,nbeta,nseg_time_temp,nus,Gs,s,p,darton,opt)
  {
    
    PBx=PBirthC(treeI,Top_idx,tree,VarType,x,Rulemat)
    r=runif(1)
    n=Nnode
    if(r<PBx)
    {
      BD=1
      
      dr_bot_node=DrBotNodeC(treeI,Top_idx,tree,VarType,x,Rulemat)
      
      idx=dr_bot_node$idx_select
      Pbot=dr_bot_node$nprob
      
      PGn = PGrow(tree,treeI,idx)
      
      
      if(darton){
        
        if(p<=(opt$nwarmup/2))
        {
          
          VarI = DrPriVar(tree,treeI,idx) # draw variable
          cat("regular var",VarI,"\n")
          
        }else{
          
          VarI = DrPriVar_Dirichlet(s) # draw variable
        }
        
      }else{
        
        VarI = DrPriVar(tree,treeI,idx)
      }
      
      
      if(!(tree[[treeI]][[paste("node",idx,sep = "")]]$VarAvail[VarI]==1))
      {
        done=0
        
        list(tree=tree,alpha=-1,BD=BD,done=done,Nnode=n,idx=idx,Var=VarI,tau=tree[[treeI]][[paste("node",idx,sep = "")]]$tau,g=tree[[treeI]][[paste("node",idx,sep = "")]]$g)
        
      }else{
        
        rule=SplitRule(tree,treeI,idx,x,VarI,VarType,RuleNum,Rulemat) # draw rule
        
        
        
        tree[[treeI]][[paste("node",idx,sep = "")]]$Var=VarI
        tree[[treeI]][[paste("node",idx,sep = "")]]$Rule=rule$Rule
        
        #tree=SpawnChildren(tree,treeI,idx,rule$LeftEx,rule$RightEx,x,VarType,RuleNum,Rulemat) # create children
        SpawnChildrenC(treeI,idx,rule$LeftEx,rule$RightEx,VarI, rule$Rule, tree, VarType,x,RuleNum,Rulemat) # create children
        
        n=n+2
        
        PDy = 1.0-PBirthC(treeI,Top_idx,tree,VarType,x,Rulemat)
        PGl=PGrow(tree,treeI,2*idx)
        PGr=PGrow(tree,treeI,2*idx+1)
        
        Pnog=1/NogNumberC(treeI,Top_idx, tree)
        
        
        # PDy: P(PRUNE)
        # Pnog: 1/w2*: 1/number of Nog nodes
        # PGn: P(SPLIT)
        # Pbot: 1/b: 1/number of bottom nodes
        alpha1 = (PGn*(1.0-PGl)*(1.0-PGr)*PDy*Pnog)/((1.0-PGn)*PBx*Pbot) # transition ratio * tree structure ratio
        
        # Drawing new tausq
        tau_prop=rep(1,2)
        g_prop=rep(1,2)
        
        zz=param_random+runif(1)*(1-2*param_random)
        tau_prop[1]=tree[[treeI]][[paste("node",idx,sep = "")]]$tau*(zz/(1-zz))
        tau_prop[2]=tree[[treeI]][[paste("node",idx,sep = "")]]$tau*((1-zz)/zz)
        
        tt=param_random+runif(1)*(1-2*param_random)
        g_prop[1]=tree[[treeI]][[paste("node",idx,sep = "")]]$g*(tt/(1-tt))
        g_prop[2]=tree[[treeI]][[paste("node",idx,sep = "")]]$g*((1-tt)/tt)
        
        
        loglike_prop=0
        log_beta_prop=0
        log_beta_prior_prop=0
        log_tau_prior_prop=0
        log_g_prior_prop=0
        
        nfreq <- floor(nseg_time_temp/2)
        fhat=matrix(0,nfreq+1,2)
        
        # Drawing a new value of beta 
        # Evaluating the Likelihood, Proposal and Prior Densities at the Proposed values
        
        beta_prop=matrix(0,nbeta,2)
        jj=0
        for (k in (2*idx):(2*idx+1))
        {
          
          jj=jj+1
          postbeta_1=postbeta(tree,treeI,k,nseg_time_temp,tau_prop[jj],YDat,nbeta,opt)
          beta_prop[,jj]=rmvnorm(1,postbeta_1$beta_mean,0.5*(postbeta_1$beta_var+t(postbeta_1$beta_var)))
          
          log_beta_prop=log_beta_prop+dmvnorm(beta_prop[,jj],postbeta_1$beta_mean,0.5*(postbeta_1$beta_var+t(postbeta_1$beta_var)),log = T)
          log_beta_prior_prop=log_beta_prior_prop+dmvnorm(beta_prop[,jj],matrix(0,nbeta,1),diag(c(opt$sigmasqalpha, tau_prop[jj]*matrix(1,opt$nbasis,1))),log = T) # Prior Density of beta
          log_tau_prior_prop=log_tau_prior_prop+log(dgamma(1/tau_prop[jj],nus/2,scale=g_prop[jj]/nus)) # Prior Density of Tausq
          log_g_prior_prop=log_g_prior_prop+log(dgamma(1/g_prop[jj],1/2,scale=Gs^2)) # Prior Density of g
          fhat[,jj]=postbeta_1$nu_mat%*%beta_prop[,jj]
          log_prop_spec_dens=whittle_like(postbeta_1$y,fhat[,jj],nseg_time_temp) # Loglikelihood  at proposed values
          loglike_prop=loglike_prop+log_prop_spec_dens
          
        }
        
        # Calculating Jacobian
        log_jacobian=log(2*tree[[treeI]][[paste("node",idx,sep = "")]]$tau/(zz*(1-zz)))+log(2*tree[[treeI]][[paste("node",idx,sep = "")]]$g/(tt*(1-tt)))
        
        # Calculating log proposal density at proposed values q(T*,M* | T,M)
        log_proposal_prop = log_beta_prop
        
        # Calculating log prior density at proposed values
        log_prior_prop = log_beta_prior_prop+log_tau_prior_prop+log_g_prior_prop
        
        # Calculating target density at proposed values
        log_target_prop=loglike_prop+log_prior_prop		
        
        
        # CURRENT VALUES		
        # Evaluating the Likelihood, Proposal and Prior Densities at the Current values
        
        loglike_curr=0
        log_beta_curr=0
        log_beta_prior_curr=0
        log_tau_prior_curr=0
        log_g_prior_curr=0
        
        # Beta proposal and prior
        
        postbeta_3=postbeta(tree,treeI,idx,nseg_time_temp,tree[[treeI]][[paste("node",idx,sep = "")]]$tau,YDat,nbeta,opt)
        log_beta_curr=log_beta_curr+dmvnorm(tree[[treeI]][[paste("node",idx,sep = "")]]$beta,postbeta_3$beta_mean,0.5*(postbeta_3$beta_var+t(postbeta_3$beta_var)),log = T)
        log_beta_prior_curr=log_beta_prior_curr+dmvnorm(tree[[treeI]][[paste("node",idx,sep = "")]]$beta,matrix(0,nbeta,1),diag(c(opt$sigmasqalpha, tree[[treeI]][[paste("node",idx,sep = "")]]$tau*matrix(1,opt$nbasis,1))),log=T)
        log_tau_prior_curr=log_tau_prior_curr+log(dgamma(1/tree[[treeI]][[paste("node",idx,sep = "")]]$tau,nus/2,scale=tree[[treeI]][[paste("node",idx,sep = "")]]$g/nus))
        log_g_prior_curr=log_g_prior_curr+log(dgamma(1/tree[[treeI]][[paste("node",idx,sep = "")]]$g,1/2,scale=Gs^2))
        
        # Log likelihood  at current values
        fhat_curr=postbeta_3$nu_mat%*%matrix(tree[[treeI]][[paste("node",idx,sep = "")]]$beta,nbeta,1)
        log_curr_spec_dens=whittle_like(postbeta_3$y,fhat_curr,nseg_time_temp)
        loglike_curr=loglike_curr+log_curr_spec_dens
        
        # Calculating log proposal density at current values
        log_proposal_curr=log_beta_curr
        
        # Calculating priors at current values
        log_prior_curr=log_beta_prior_curr+log_tau_prior_curr+log_g_prior_curr
        
        # Evaluating target densities at current values
        log_target_curr=loglike_curr+log_prior_curr
        
        alpha=min(1,exp(log_target_prop-log_target_curr+log_proposal_curr-log_proposal_prop+log_jacobian)*alpha1)
        
        r1=runif(1)
        if(r1<alpha)
        {
          done=1
          tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau=tau_prop[1]
          tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau=tau_prop[2]
          
          tree[[treeI]][[paste("node",2*idx,sep = "")]]$g=g_prop[1]
          tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g=g_prop[2]
          
          tree[[treeI]][[paste("node",2*idx,sep = "")]]$beta=beta_prop[,1]
          tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$beta=beta_prop[,2]
          
          tree[[treeI]][[paste("node",2*idx,sep = "")]]$fhat=fhat[,1]
          tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$fhat=fhat[,2]
          
          
          list(tree=tree,alpha=alpha,BD=BD,done=done,Nnode=n,idx=idx,Var=VarI,cutpoint=rule$Rule,taul=tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau,taur=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau,gl=tree[[treeI]][[paste("node",2*idx,sep = "")]]$g,gr=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g)
          
        }else
        {
          n=n-2
          tree=KillChildren(tree,treeI,idx)
          tree[[treeI]][[paste("node",idx,sep = "")]]$fhat=as.vector(fhat_curr)
          
          done=0
          
          list(tree=tree,alpha=alpha,BD=BD,done=done,Nnode=n,idx=idx,Var=VarI,cutpoint=rule$Rule,tau=tree[[treeI]][[paste("node",idx,sep = "")]]$tau,g=tree[[treeI]][[paste("node",idx,sep = "")]]$g)
          
        }
      }
      
    }else
    {
      BD=0
      
      PDx=1-PBx
      
      dr_nog_node=DrNogNodeC(treeI,Top_idx,tree)
      Pnog=dr_nog_node$nprob  # same as 1/(NogNodes(n)$NogNumber)?
      idx=dr_nog_node$idx_select
      
      PGl = PGrow(tree,treeI,2*idx)
      PGr = PGrow(tree,treeI,2*idx+1)
      
      #Copy rule
      var_copy=tree[[treeI]][[paste("node",idx,sep = "")]]$Var
      rule_copy=tree[[treeI]][[paste("node",idx,sep = "")]]$Rule
      betaL=tree[[treeI]][[paste("node",2*idx,sep = "")]]$beta
      betaR=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$beta
      tauL=tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau
      tauR=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau
      gL=tree[[treeI]][[paste("node",2*idx,sep = "")]]$g
      gR=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g
      fhatL=tree[[treeI]][[paste("node",2*idx,sep = "")]]$fhat
      fhatR=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$fhat
      
      
      Left_ex=1-tree[[treeI]][[paste("node",2*idx,sep = "")]]$VarAvail[tree[[treeI]][[paste("node",idx,sep = "")]]$Var]
      Right_ex=1-tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$VarAvail[tree[[treeI]][[paste("node",idx,sep = "")]]$Var]
      
      # CURRENT VALUES
      # Evaluating the Likelihood, Proposal and Prior Densities at the Current values
      # Beta proposal and prior
      loglike_curr=0
      log_beta_curr=0
      log_beta_prior_curr=0
      log_tau_prior_curr=0
      log_g_prior_curr=0
      
      nfreq <- floor(nseg_time_temp/2)
      fhat=matrix(0,nfreq+1,2)
      
      jj=0
      for (k in (2*idx):(2*idx+1))
      {
        jj=jj+1
        
        postbeta_5=postbeta(tree,treeI,k,nseg_time_temp,tree[[treeI]][[paste("node",k,sep = "")]]$tau,YDat,nbeta,opt)
        log_beta_curr=log_beta_curr+dmvnorm(tree[[treeI]][[paste("node",k,sep = "")]]$beta,postbeta_5$beta_mean,0.5*(postbeta_5$beta_var+t(postbeta_5$beta_var)),log = T)
        log_beta_prior_curr=log_beta_prior_curr+dmvnorm(tree[[treeI]][[paste("node",k,sep = "")]]$beta,matrix(0,nbeta,1),diag(c(opt$sigmasqalpha, tree[[treeI]][[paste("node",k,sep = "")]]$tau*matrix(1,opt$nbasis,1))),log = T)
        log_tau_prior_curr=log_tau_prior_curr+log(dgamma(1/tree[[treeI]][[paste("node",k,sep = "")]]$tau,nus/2,scale=tree[[treeI]][[paste("node",k,sep = "")]]$g/nus))
        log_g_prior_curr=log_g_prior_curr+log(dgamma(1/tree[[treeI]][[paste("node",k,sep = "")]]$g,1/2,scale=Gs^2))
        
        # Loglikelihood  at current values
        fhat[,jj]=postbeta_5$nu_mat%*%matrix(tree[[treeI]][[paste("node",k,sep = "")]]$beta,nbeta,1)
        log_curr_spec_dens=whittle_like(postbeta_5$y,fhat[,jj],nseg_time_temp)
        loglike_curr=loglike_curr+log_curr_spec_dens
        
      }
      
      # Calculating log proposal density at current values
      log_proposal_curr=log_beta_curr
      
      # Calculating priors at current values
      log_prior_curr=log_beta_prior_curr+log_tau_prior_curr+log_g_prior_curr
      
      # Evaluating Target density at current values(taking duplicates into consideration)
      log_target_curr=loglike_curr+log_prior_curr
      
      #### PROPOSAL VALUES
      tau_prop=sqrt(tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau*tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau) # Combining 2 taus into 1
      g_prop=sqrt(tree[[treeI]][[paste("node",2*idx,sep = "")]]$g*tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g) # Combining 2 taus into 1
      
      # Evaluating the Likelihood, Proposal and Prior Densities at the Proposed values
      
      loglike_prop=0
      log_beta_prop=0
      log_beta_prior_prop=0
      log_tau_prior_prop=0
      log_g_prior_prop=0
      
      # Computing mean and variances for beta proposals
      
      postbeta_4=postbeta(tree,treeI,idx,nseg_time_temp,tau_prop,YDat,nbeta,opt)
      beta_prop=rmvnorm(1,postbeta_4$beta_mean,0.5*(postbeta_4$beta_var+t(postbeta_4$beta_var))) # Drawing a new value of beta
      
      # Loglikelihood  at proposed values
      fhat=postbeta_4$nu_mat%*%matrix(beta_prop,nbeta,1)
      log_prop_spec_dens=whittle_like(postbeta_4$y,fhat,nseg_time_temp)
      loglike_prop=loglike_prop+log_prop_spec_dens
      
      # Evaluating the Prior Densities at the Proposed values for tau and
      
      # Beta
      log_beta_prior_prop=log_beta_prior_prop+dmvnorm(beta_prop,matrix(0,nbeta,1),diag(c(opt$sigmasqalpha, tau_prop*matrix(1,opt$nbasis,1))), log = T)
      log_tau_prior_prop=log_tau_prior_prop+log(dgamma(1/tau_prop,nus/2,scale=g_prop/nus))
      log_g_prior_prop=log_g_prior_prop+log(dgamma(1/tau_prop,1/2,scale=Gs^2))
      
      # Evaluating the Proposal Densities at the Proposed values of beta
      
      log_beta_prop=log_beta_prop+dmvnorm(beta_prop,postbeta_4$beta_mean,0.5*(postbeta_4$beta_var+t(postbeta_4$beta_var)),log = T)
      
      # Calculating Jacobian(sum of log Jacobian for each covariate seg)
      log_jacobian_tau=-log(2*(sqrt(tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau)+sqrt(tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau))^2)
      log_jacobian_g=-log(2*(sqrt(tree[[treeI]][[paste("node",2*idx,sep = "")]]$g)+sqrt(tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g))^2)
      log_jacobian=log_jacobian_tau+log_jacobian_g
      
      # Calculating log proposal density at proposed values
      log_proposal_prop=log_beta_prop
      
      # Calculating log prior density at proposed values
      log_prior_prop=log_beta_prior_prop+log_tau_prior_prop+log_g_prior_prop
      
      # Evaluating Target density at proposed values(taking duplicates into consideration)
      log_target_prop=loglike_prop+log_prior_prop
      
      
      tree=KillChildren(tree,treeI,idx)
      
      n=n-2
      PBy=PBirthC(treeI,Top_idx,tree,VarType,x,Rulemat)
      PGn=PGrow(tree,treeI,idx)
      Pbot=PrBotNodeC(treeI,Top_idx,idx,tree)
      alpha1 =((1.0-PGn)*PBy*Pbot)/(PGn*(1.0-PGl)*(1.0-PGr)*PDx*Pnog)
      
      alpha=min(1,exp(log_target_prop-log_target_curr+log_proposal_curr-log_proposal_prop+log_jacobian)*alpha1)
      
      r2=runif(1)
      if(r2<alpha)
      {
        done=1
        tree[[treeI]][[paste("node",idx,sep = "")]]$tau=tau_prop
        tree[[treeI]][[paste("node",idx,sep = "")]]$g=g_prop
        tree[[treeI]][[paste("node",idx,sep = "")]]$beta=beta_prop
        tree[[treeI]][[paste("node",idx,sep = "")]]$fhat=as.vector(fhat)
        
        list(tree=tree,alpha=alpha,BD=BD,done=done,Nnode=n,idx=idx,tau=tree[[treeI]][[paste("node",idx,sep = "")]]$tau,g=tree[[treeI]][[paste("node",idx,sep = "")]]$g)
        
      }else
      {
        n=n+2
        tree[[treeI]][[paste("node",idx,sep = "")]]$Var = var_copy
        tree[[treeI]][[paste("node",idx,sep = "")]]$Rule = rule_copy
        
        
        #tree=SpawnChildrenC(tree,treeI,idx,Left_ex,Right_ex,x,VarType,RuleNum,Rulemat)
        SpawnChildrenC(treeI,idx,Left_ex,Right_ex,var_copy,rule_copy,tree,VarType,x,RuleNum,Rulemat)
        
        ### update VarAvail
        update=DrBotNodeC(treeI,Top_idx,tree,VarType,x,Rulemat)
        
        
        tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau=tauL
        tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau=tauR
        tree[[treeI]][[paste("node",2*idx,sep = "")]]$g=gL
        tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g=gR
        tree[[treeI]][[paste("node",2*idx,sep = "")]]$beta=betaL
        tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$beta=betaR
        tree[[treeI]][[paste("node",2*idx,sep = "")]]$fhat=fhatL
        tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$fhat=fhatR
        
        done=0
        
        list(tree=tree,alpha=alpha,BD=BD,done=done,Nnode=n,idx=idx,taul=tree[[treeI]][[paste("node",2*idx,sep = "")]]$tau,taur=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$tau,gl=tree[[treeI]][[paste("node",2*idx,sep = "")]]$g,gr=tree[[treeI]][[paste("node",2*idx+1,sep = "")]]$g)
        
      }
      
      
    }
    
  }
