SplitRule_change <-
function(tree,treeI,idx,varidx,x,VarType,Rulemat)
  {
    
    LeftEx=0
    RightEx=0
    
    if(VarType[varidx]=="CAT")
    {
      get_cats=unique(x[tree[[treeI]][[paste("node",idx,sep = "")]]$DataList,varidx])
      Ncat=length(get_cats)
      
      if(Ncat-sum(tree[[treeI]][[paste("node",idx,sep = "")]]$Rule)==1)
      {
        LeftEx=1
      }
      if(sum(tree[[treeI]][[paste("node",idx,sep = "")]]$Rule)==1)
      {
        RightEx=1
      }
      
      list(LeftEx=LeftEx,RightEx=RightEx,Rule=tree[[treeI]][[paste("node",idx,sep = "")]]$Rule)
      
    }else{
      
      x_min=min(x[tree[[treeI]][[paste("node",idx,sep = "")]]$DataList,varidx])
      x_max=max(x[tree[[treeI]][[paste("node",idx,sep = "")]]$DataList,varidx])
      
      LeftI=min(which(Rulemat[[varidx]]>=x_min))
      RightI=max(which(Rulemat[[varidx]]<x_max))
      
      if(tree[[treeI]][[paste("node",idx,sep = "")]]$Rule==LeftI)
      {
        LeftEx=1
      }
      
      if(tree[[treeI]][[paste("node",idx,sep = "")]]$Rule==RightI)
      {
        RightEx=1
      }
      
      list(LeftEx=LeftEx,RightEx=RightEx,Rule=tree[[treeI]][[paste("node",idx,sep = "")]]$Rule)
      
    }
    
  }
