SplitRule <-
function(tree,treeI,idx,x,varidx,VarType,RuleNum,Rulemat)
  {
    
    LeftEx=0
    RightEx=0
    
    if(VarType[varidx]=="CAT")
    {
      
      get_cats=unique(x[tree[[treeI]][[paste("node",idx,sep = "")]]$DataList,varidx])
      Ncat=length(get_cats)
      
      index=c()
      sel=rep(0,Ncat)
      for(i in 1:Ncat)
      {
        index[i]=which(Rulemat[[varidx]]==get_cats[i])
      }
      
      rule=rep(0,RuleNum[varidx])
      
      sel[1]=1
      if(Ncat>2)
      {
        aa=sample(2:Ncat,1,replace = F)
        sel[aa]=0
        sel[-c(1,aa)]=sample(c(0,1),Ncat-2,replace=T)
        
      }else{
        
        sel[2]=0
      }
      rule[index] = sel
      
      
      if(Ncat-sum(sel)==1)
      {
        LeftEx=1
      }
      if(sum(sel)==1)
      {
        RightEx=1
      }
      
      list(LeftEx=LeftEx,RightEx=RightEx,Rule=rule)
      
    }else{
      
      x_min=min(x[tree[[treeI]][[paste("node",idx,sep = "")]]$DataList,varidx])
      x_max=max(x[tree[[treeI]][[paste("node",idx,sep = "")]]$DataList,varidx])
      
      LeftI=min(which(Rulemat[[varidx]]>=x_min))
      RightI=max(which(Rulemat[[varidx]]<x_max))
      
      numsplit=RightI-LeftI+1
      tree[[treeI]][[paste("node",idx,sep = "")]]$Rule=LeftI+floor(runif(1)*numsplit)
      
      if(tree[[treeI]][[paste("node",idx,sep = "")]]$Rule==LeftI)
      {
        LeftEx=1
      }
      
      if(tree[[treeI]][[paste("node",idx,sep = "")]]$Rule==RightI)
      {
        RightEx=1
      }
      
      list(LeftEx=LeftEx,RightEx=RightEx,Rule=tree[[treeI]][[paste("node",idx,sep = "")]]$Rule)
      
    }
  }
