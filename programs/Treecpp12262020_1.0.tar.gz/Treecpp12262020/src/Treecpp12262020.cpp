#include <Rcpp.h>
#include <Rmath.h>
//#include <R.h>
//#include <RcppArmadillo.h>
#include <iostream> 
#include <string> 
#include <cmath>
#include <math.h>
// //[[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace std;

// [[Rcpp::export]]
String concatenate(StringVector a)
{
  String c;
  std::ostringstream x;
  
  // concatenate inputs
  for (int i = 0; i < a.size(); i++)
    x << a[i];
  
  c.push_back(x.str());
  
  return c;
  
}

// [[Rcpp::export]]
Rcpp::List tree_access(int treeI, int idx, Rcpp::List tree)
{
  Rcpp::StringVector node_idx(2);
  node_idx[0]="node";
  node_idx[1]=idx;
  
  
  Rcpp::List tr=as<List>(as<List>(tree[treeI-1])[concatenate(node_idx)]);
  return(tr);
}


// [[Rcpp::export]]
int BotNumberC(int treeI,int idx,Rcpp::List tree)
{
  
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  
  int Bot_Number=0;
  
  if(tree_curr["Bot"])
  {
    NumericVector datalist=tree_curr["DataList"];
    if(datalist.length()>1)
    {
      Bot_Number=Bot_Number+1;
      
    }
    
  }else
  {
    
    Bot_Number=BotNumberC(treeI,2*idx,tree)+BotNumberC(treeI,2*idx+1,tree);
    
  }
  return(Bot_Number);
}


// [[Rcpp::export]]
int BotNumber_noconditionC(int treeI,int idx,Rcpp::List tree)
{
  
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  
  int Bot_Number=0;
  
  if(tree_curr["Bot"])
  {
      Bot_Number=Bot_Number+1;
    
  }else
  {
    
    Bot_Number=BotNumberC(treeI,2*idx,tree)+BotNumberC(treeI,2*idx+1,tree);
    
  }
  return(Bot_Number);
}



// [[Rcpp::export]]
NumericVector BotIndexC(int treeI,int idx,Rcpp::List tree)
{
  
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  NumericVector Bot_Index;
  
  if(!tree_curr["Bot"])
  {
    NumericVector Ll=BotIndexC(treeI,2*idx,tree);
    NumericVector Lr=BotIndexC(treeI,2*idx+1,tree);
    for(int i=0;i<Ll.length();i++)
    {
      Bot_Index.push_back(Ll[i]);
    }
    for(int i=0;i<Lr.length();i++)
    {
      Bot_Index.push_back(Lr[i]);
    }
    
  }else
  {
    NumericVector datalist=tree_curr["DataList"];
    if(datalist.length()>1)
    {
      Bot_Index.push_back(idx);
      
    }
  }
  return(Bot_Index);
}

// [[Rcpp::export]]
NumericVector BotIndex_noconditionC(int treeI,int idx,Rcpp::List tree)
{
  
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  NumericVector Bot_Index;
  
  if(!tree_curr["Bot"])
  {
    NumericVector Ll=BotIndexC(treeI,2*idx,tree);
    NumericVector Lr=BotIndexC(treeI,2*idx+1,tree);
    for(int i=0;i<Ll.length();i++)
    {
      Bot_Index.push_back(Ll[i]);
    }
    for(int i=0;i<Lr.length();i++)
    {
      Bot_Index.push_back(Lr[i]);
    }
    
  }else
  {
    
      Bot_Index.push_back(idx);
      
  }
  return(Bot_Index);
}

// [[Rcpp::export]]
Rcpp::List DrBotNodeC(int treeI,int idx,Rcpp::List tree,CharacterVector VarType,DataFrame x, Rcpp::List Rulemat)
{
  // Rcpp::List tree_parent=tree_access(treeI,idx,tree);
  // NumericVector VarAvail_p1=tree_parent["VarAvail"];
  
   int nbot=BotNumberC(treeI,idx,tree);
   NumericVector botidx=BotIndexC(treeI,idx,tree);
  
   
   int can=0;
   double nprob=0.0;
   int idx_select=0;
   
   NumericVector probs (nbot);
   NumericVector VarAvail;
  
  NumericVector rule_sum (nbot);
  List re=List::create(Named("can",0), Named("idx_select")=0 , _["nprob"]=0);
  if(botidx.length()==0)
  {
    can=0;
    nprob=0.0;
    idx_select=0;

  }else{

    for(int i=0;i<nbot;i++)
    {
      
      Rcpp::List tree_curr=tree_access(treeI,botidx[i],tree);
      VarAvail=tree_curr["VarAvail"];
      NumericVector a (VarAvail.length());
      for(int k=0;k<VarAvail.length();k++)
      {
        a[k]=VarAvail[k];
      }
      
      if(sum(VarAvail))
      {
        probs[i]=1;
      }else{
        probs[i]=0;
      }


      NumericVector VarI;
      if(probs[i]==1)
      {

        for(int q=0;q<VarAvail.length();q++)
        {
          if(VarAvail[q]==1)
          {
            VarI.push_back(q);
          }
        }
  
  
        NumericVector rule_can (VarI.length());
        for (int j=0;j<VarI.length();j++)
        {

          NumericVector datalist=tree_curr["DataList"];

          if(VarType[VarI[j]]=="ORD")
          {
            NumericVector x_row=x[VarI[j]];
            NumericVector element=x_row[datalist-1];

            double x_min;
            double x_max;

            x_min=min(element);
            x_max=max(element);

            NumericVector rule_mat=Rulemat[VarI[j]];

            for(int q=0;q<rule_mat.length();q++)
            {
              if(rule_mat[q]<x_max)
              {
                if(rule_mat[q]>x_min)
                {
                  rule_can[j]=1;
                }else{
                  rule_can[j]=0;
                }

              }
            }
            
            
               a[VarI[j]]=rule_can[j];

         }else if(VarType[VarI[j]]=="CAT"){

            CharacterVector x_row_cat=x[VarI[j]];
            CharacterVector element_cat=x_row_cat[datalist-1];

            CharacterVector get_cats;


            get_cats=unique(element_cat);


            if(get_cats.length()>1)
            {
              rule_can[j]=1;
            }else{
              rule_can[j]=0;
            }


            a[VarI[j]]=rule_can[j];


          }else{

            int t_interval=0;
            int tmax=tree_curr["Tmax"];
            int tmin=tree_curr["Tmin"];

            t_interval=tmax-tmin+1;

            if(t_interval>100)
            {
              rule_can[j]=1;
            }else{
              rule_can[j]=0;
            }

            a[VarI[j]]=rule_can[j];

          }



        }


        int sum_rulecan=sum(rule_can);
        if(sum_rulecan)
        {
          rule_sum[i]=1;
        }else{
          rule_sum[i]=0;
        }

      }else
      {
        rule_sum[i]=0;
      }

      
      Rcpp::StringVector node_idx_l(2);
      node_idx_l[0]="node";
      node_idx_l[1]=botidx[i];
      
      as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_l)]))["VarAvail"]=a;
      
    }
    
    

    if(sum(rule_sum))
    {

      can=1;
      probs=rule_sum/sum(rule_sum);

      double u=R::runif(0,1);
      double s=probs[0];
      int i=0;
      while(s<u)
      {
        i=i+1;
        s=s+probs[i];
      }

      idx_select=botidx[i];
      nprob=probs[i];

    }else {

      can=0;
      nprob=0;
      idx_select=0;
    }

  }


  re[0]=can;
  re[1]=idx_select;
  re[2]=nprob;
 
  return(re);
  
}


// [[Rcpp::export]]
double PBirthC(int treeI,int Top_idx,Rcpp::List tree,CharacterVector VarType,DataFrame x, Rcpp::List Rulemat)
{
  int can=DrBotNodeC(treeI,Top_idx,tree, VarType, x, Rulemat)["can"];
  double PB;
  Rcpp::List tree_a=tree[treeI-1];
  
  if(!can)
  {
    PB=0;
    
  }else if(tree_a.length()==1)
  {
    PB=1;
  }else
  {
    PB=0.5;
  }
  
  return(PB);
}

// [[Rcpp::export]]
void apply_sum_vecC(NumericVector a, IntegerVector b,NumericVector temp_out_m, int nloop, int p)
{
  
  //NumericVector temp_out(b[1]*b[2]);
  int ii,kk;
  for(ii=0;ii<(b[1]*b[2]);ii++)
  {
    double sum=0;
    for(kk=0;kk<b[0];kk++)
    {
      sum=sum+a[ii*b[0]+kk];
      
    }
    //temp_out[ii]=sum;
    //temp_out_m[ii]=sum;
    temp_out_m[(p-1)+nloop*ii]=sum;
  }
  
  
}

// [[Rcpp::export]]
double PrBotNodeC(int treeI,int idx,int index, Rcpp::List tree)
{
  
  int nbot=BotNumberC(treeI,idx,tree);
  NumericVector botidx=BotIndexC(treeI,idx,tree);
  double PrNode=-1.0;
  NumericVector probs (nbot);
  
  // Add error message if idx is not a bottom node
  
  for(int i=0;i<nbot;i++) 
  {
    Rcpp::List tree_curr=tree_access(treeI,botidx[i],tree);
    NumericVector VarAvail=tree_curr["VarAvail"];
    if(sum(VarAvail))
    {
      probs[i]=1;
    }else{
      probs[i]=0;
    }
    
  }
  
  double sum_a=sum(probs);
  
  probs=probs/sum_a;
  
  //NumericVector index_a;
  for(int j=0;j<botidx.length();j++)
  {
    if(botidx[j]==index)
    {
      PrNode=probs[j];
    }
  }
  
  return(PrNode);
  
}


// [[Rcpp::export]]
int NogNumberC(int treeI,int idx, Rcpp::List tree)
{
  
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  int Nog_Number=0;
  
  if(tree_curr["Bot"])
  {
    Nog_Number=0;
    
  }else if(tree_curr["Nog"])
  {
    Nog_Number=1;
    
  }else
  {
    Nog_Number=NogNumberC(treeI,2*idx,tree)+NogNumberC(treeI,2*idx+1,tree);
  }
  return(Nog_Number);
}

// [[Rcpp::export]]
NumericVector NogIndexC(int treeI,int idx,Rcpp::List tree)
{
  
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  NumericVector Nog_Index;
  
  if(tree_curr["Nog"])
  {
    Nog_Index.push_back(idx);
    
  }else if(!tree_curr["Bot"])
  {
    
    NumericVector Ll=NogIndexC(treeI,2*idx,tree);
    NumericVector Lr=NogIndexC(treeI,2*idx+1,tree);
    for(int i=0;i<Ll.length();i++)
    {
      Nog_Index.push_back(Ll[i]);
    }
    for(int i=0;i<Lr.length();i++)
    {
      Nog_Index.push_back(Lr[i]);
    }
    
  }
  return(Nog_Index);
}



// [[Rcpp::export]]
Rcpp::List DrNogNodeC(int treeI,int idx,Rcpp::List tree)
{
 
  int nnog=NogNumberC(treeI,idx,tree);
 
  NumericVector nogidx=NogIndexC(treeI,idx,tree);
  List re =List::create(Named("idx_select",0), _["nprob"]=0);
  
  float a=R::runif(0,0.99)*nnog;
  int NodeI=floor(a)+1;
  int idx_select=nogidx[NodeI-1];
  double nprob=1.0/nnog;
  
  re[0]=idx_select;
  re[1]=nprob;
  
  return(re);
  
}

// [[Rcpp::export]]
int RightC(int treeI, int idx, Rcpp::List x, int var, NumericVector Rule,Rcpp::List tree, CharacterVector VarType, IntegerVector RuleNum,Rcpp::List Rulemat)
{
  
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  //IntegerVector rule=tree_curr["Rule"];
  int res=-1;
  
  if(VarType[var-1]=="CAT")
  {
    for(int i=0; i<RuleNum[var-1]; i++)
    {
      
      StringVector rule_vector=Rulemat[var-1];
      StringVector value=x[var-1];
      
      if(value[0]==rule_vector[i])
      {
        
        
        if(Rule[i]==1)
        {
          res=1;
          
        }else
        {
          res=0;
        }
      }
    }
  }else{
    
    NumericVector rule_nu_vector=Rulemat[var-1];
    NumericVector nu_value=x[var-1];
    if(nu_value[0]>rule_nu_vector[Rule[0]-1])
    {
      res=1;
      
    }else{
      res=0;
    }
    
  }
  
  return(res);
}


// [[Rcpp::export]]
int FindNodeC(int obs,int idx,int treeI,Rcpp::List tree,DataFrame x,CharacterVector VarType, IntegerVector RuleNum,Rcpp::List Rulemat)
{
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  int node_idx=0;
  
  if(tree_curr["Bot"])
  {
    node_idx=idx;
    
  }else{
    
    int nCols=x.size();
    Rcpp::List x_row(nCols);
    for (int j=0; j<nCols;j++)
    {
      if(VarType[j]=="CAT")
      {
        
        StringVector column = x[j];
        x_row[j] = column[obs-1] ;
        
      }else{
        
        NumericVector nu_column = x[j] ;
        x_row[j] = nu_column[obs-1] ;
      }
      
    }
    
    if(RightC(treeI,idx, x_row, tree_curr["Var"], tree_curr["Rule"],tree, VarType, RuleNum, Rulemat))
    {
      node_idx=FindNodeC(obs,tree_curr["RightC"],treeI,tree,x,VarType, RuleNum, Rulemat);
      
    }else{
      
      node_idx=FindNodeC(obs,tree_curr["LeftC"],treeI,tree,x,VarType, RuleNum, Rulemat);
      
    }
    
  }
  
  return(node_idx);
  
}

// [[Rcpp::export]]
Rcpp::List TopPathC(int treeI, int idx, Rcpp::List tree)
{
  List re =List::create(Named("indexidx",0),Named("varidx",0), _["ruleidx"]=0);
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  
  NumericVector varidx;
  NumericVector ruleidx;
  NumericVector indexidx;
  
  if(tree_curr["Nog"])
  {
    varidx=tree_curr["Var"];
    ruleidx=tree_curr["Rule"];
    indexidx=idx;
  }else if(!tree_curr["Bot"]){
    
    Rcpp::List l=TopPathC(treeI, 2*idx, tree);
    Rcpp::List r=TopPathC(treeI, 2*idx+1, tree);
    
    NumericVector vl=l["varidx"];
    NumericVector vr=r["varidx"];
    NumericVector rl=l["ruleidx"];
    NumericVector rr=r["ruleidx"];
    NumericVector il=l["indexidx"];
    NumericVector ir=r["indexidx"];
    
    
   // attach current node information
    varidx.push_back(tree_curr["Var"]);
    NumericVector rulelist=tree_curr["Rule"];
    
    for(int l=0;l<rulelist.length();l++)
    {
      
      ruleidx.push_back(rulelist[l]);
    }

    indexidx.push_back(idx);
    
    // attach left branch information
    for(int i=0;i<vl.length();i++)
    {
      varidx.push_back(vl[i]);
      indexidx.push_back(il[i]);
    }
    
    for(int l=0;l<rl.length();l++)
    {
      ruleidx.push_back(rl[l]);
    }
    
    // attach right branch information
    for(int i=0;i<vr.length();i++)
    {
      varidx.push_back(vr[i]);
      indexidx.push_back(ir[i]);
      
    }
    
    for(int l=0;l<rr.length();l++)
    {
      ruleidx.push_back(rr[l]);
    }
    

      
  }
  re[0]=indexidx;
  re[1]=varidx;
  re[2]=ruleidx;
  return(re);
  
}
  

  
// [[Rcpp::export]]
int NotBotNumberC(int treeI,int idx,Rcpp::List tree)
{
    
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
    
  int sum=0;
    
  if(tree_curr["Nog"])
  {
    sum=1;
      
  }else
  {
    sum=1+NotBotNumberC(treeI,2*idx,tree)+NotBotNumberC(treeI,2*idx+1,tree);

  }
    
  return(sum);
}



// [[Rcpp::export]]
NumericVector NotBotIndexC(int treeI,int idx,Rcpp::List tree)
{
  
  Rcpp::List tree_curr=tree_access(treeI,idx,tree);
  NumericVector NotBot_Index;
  
  if(tree_curr["Nog"])
  {
    NotBot_Index.push_back(idx);
    
  }else if(!tree_curr["Bot"]){
    
    NotBot_Index.push_back(idx);
    
    NumericVector Ll=NotBotIndexC(treeI,2*idx,tree);
    NumericVector Lr=NotBotIndexC(treeI,2*idx+1,tree);
    for(int i=0;i<Ll.length();i++)
    {
      NotBot_Index.push_back(Ll[i]);
    }
    for(int i=0;i<Lr.length();i++)
    {
      NotBot_Index.push_back(Lr[i]);
    }
    
    
  }
  return(NotBot_Index);
}


List resize( const List& x, int n){
  int oldsize = x.size() ;
  List y(n) ;
  for( int i=0; i<oldsize; i++) 
  {
    y[i] = x[i] ;
  }
  return y ;
}

StringVector GetListNames( List y ){
  return y.names() ;
}



// [[Rcpp::export]]
void SetDataC(int treeI,int index, int i, int Var,NumericVector Rule,CharacterVector VarType, Rcpp::List tree, DataFrame x, IntegerVector RuleNum,Rcpp::List Rulemat)
{
  
  int nCols=x.size();
  Rcpp::List x_row(nCols);
  for (int j=0; j<nCols;j++)
  {
    if(VarType[j]=="CAT")
    {
      
      StringVector column = x[j];
      x_row[j] = column[i-1] ;
      
    }else{
      
      NumericVector nu_column = x[j] ;
      x_row[j] = nu_column[i-1] ;
    }
    
  }
  
  int stp=0;
  int idx=index;
  
  NumericVector datalist;
  List data_inial;
  Rcpp::List tree_curr;
  
  // Rcpp::List tree_childl;
  // Rcpp::List tree_childr;
  
  while(stp==0)
  {
    
    tree_curr=tree_access(treeI,idx,tree);
    //int var=tree_curr["Var"];
    
    
    if(!tree_curr["Bot"])
    {
      // tree_childl=tree_access(treeI,2*idx,tree);
      // tree_childr=tree_access(treeI,2*idx+1,tree);
      
      if(RightC(treeI,idx,x_row,Var,Rule,tree,VarType,RuleNum,Rulemat))
      {
        
        // data_inial=tree_curr["DataList"];
        // int inial=data_inial[0];
        // if(inial==0)
        // {
        //   datalist=i;
        // }else{
        // 
        //   datalist=tree_curr["DataList"];
        //   datalist.push_back(i);
        //   datalist=unique(datalist);
        // }
        // 
        // 
        // Rcpp::StringVector node_idx(2);
        // node_idx[0]="node";
        // node_idx[1]=idx;
        // 
        // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx)])[0])["DataList"]=datalist;
        
        idx=tree_curr["RightC"];
        
        
      }else{
        
        //  data_inial=tree_curr["DataList"];
        //  int inial=data_inial[0];
        //  if(inial==0)
        //  {
        //    datalist=i;
        //  }else{
        //
        //    datalist=tree_curr["DataList"];
        //    datalist.push_back(i);
        //    datalist=unique(datalist);
        //  }
        //
        //
        //  Rcpp::StringVector node_idx(2);
        //  node_idx[0]="node";
        //  node_idx[1]=idx;
        //
        //  as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx)])[0])["DataList"]=datalist;
        //
        idx=tree_curr["LeftC"];
        //
        //
        
      }
      
    }else{
      
      data_inial=tree_curr["DataList"];
      int inial=data_inial[0];
      if(inial==0)
      {
        datalist=i;
        
      }else{
        
        datalist=tree_curr["DataList"];
        datalist.push_back(i);
        //datalist=unique(datalist);
      }
      
      Rcpp::StringVector node_idx(2);
      node_idx[0]="node";
      node_idx[1]=idx;
      
      
      as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx)]))["DataList"]=datalist;
      
      stp=1;
      
    }
    
  } 
  
}


// [[Rcpp::export]]
void SpawnChildrenC(int treeI,int idx,int LeftEx,int RightEx,int Var,NumericVector Rule, Rcpp::List tree, CharacterVector VarType,DataFrame x, IntegerVector RuleNum, Rcpp::List Rulemat)
{
    
    int idx_p=0;
    Rcpp::List tree_curr=tree_access(treeI,idx,tree);
   
    NumericVector datalist;
   
    Rcpp::StringVector node_idx(2);
    node_idx[0]="node";
    node_idx[1]=idx;
    
    tree_curr["Bot"]=0;
    tree_curr["Nog"]=1;
    
    if(!tree_curr["Top"])
    {
      idx_p=tree_curr["Parent"];
      Rcpp::List tree_parent=tree_access(treeI,idx_p,tree);
      
      // Rcpp::StringVector node_idx_p(2);
      // node_idx_p[0]="node";
      // node_idx_p[1]=idx_p;
      // 
      // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_p)]))["Nog"]=0;
      
      tree_parent["Nog"]=0;
    }
    
    tree_curr["LeftC"]=2*idx;
    tree_curr["RightC"]=2*idx+1;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx)]))["LeftC"]=2*idx;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx)]))["RightC"]=2*idx+1;
    
    
    //increase size of tree
    List tree_temp=tree[treeI-1];
    StringVector list_name=GetListNames(tree[treeI-1]);
    
    Rcpp::StringVector node_idx_l(2);
    node_idx_l[0]="node";
    node_idx_l[1]=2*idx;
    
    Rcpp::StringVector node_idx_r(2);
    node_idx_r[0]="node";
    node_idx_r[1]=2*idx+1;
    
    String namel=concatenate(node_idx_l);
    String namer=concatenate(node_idx_r);
    
    
    list_name.push_back(namel);
    list_name.push_back(namer);
    
    int n=tree_temp.length()+2;
    
    tree[treeI-1] = resize(tree[treeI-1], n);
    
    
    as<List>(tree[treeI-1]).names()=list_name;
    
    List l = List::create(Named("Top",0), Named("Bot")=0 , _["Nog"]=0,_["Parent"]=0,_["LeftC"]=0,_["RightC"]=0,
                                _["Var"]=0,_["Rule"]=0,_["VarAvail"]=NULL,_["DataList"]=NULL,_["tau"]=0,_["g"]=0,_["beta"]=0,_["Tmin"]=0,_["Tmax"]=0);
    
    List m = List::create(Named("Top",0), Named("Bot")=0 , _["Nog"]=0,_["Parent"]=0,_["LeftC"]=0,_["RightC"]=0,
                                _["Var"]=0,_["Rule"]=0,_["VarAvail"]=NULL,_["DataList"]=NULL,_["tau"]=0,_["g"]=0,_["beta"]=0,_["Tmin"]=0,_["Tmax"]=0);
    
    
    as<List>(tree[treeI-1])[namel]=l;
    as<List>(tree[treeI-1])[namer]=m;
    
    
    
    //Left child
    Rcpp::List leftchild=tree_access(treeI,2*idx,tree);
    leftchild["Top"]=0;
    leftchild["Bot"]=1;
    leftchild["Nog"]=0;
    leftchild["Parent"]=idx;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_l)]))["Top"]=0;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_l)]))["Bot"]=1;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_l)]))["Nog"]=0;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_l)]))["Parent"]=idx;
    
    
    NumericVector varavail_parent_l=tree_curr["VarAvail"];
    int length_var=varavail_parent_l.length();
    NumericVector a (length_var);
    
    if(LeftEx==1)
    {
      
      for(int i=0;i<length_var;i++)
      {
        if(i!=(Var-1))
        {
          a[i]=varavail_parent_l[i];
        }else{
          a[i]=0;
        }
      }
      
    }else{
      
      for(int i=0;i<length_var;i++)
      {
        
        a[i]=varavail_parent_l[i];
        
      }
    }
    
    leftchild["VarAvail"]=a;
    
    //as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_l)]))["VarAvail"]=a;
    
    //Right Child
    Rcpp::List rightchild=tree_access(treeI,2*idx+1,tree);
    rightchild["Top"]=0;
    rightchild["Bot"]=1;
    rightchild["Nog"]=0;
    rightchild["Parent"]=idx;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_r)]))["Top"]=0;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_r)]))["Bot"]=1;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_r)]))["Nog"]=0;
    // as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_r)]))["Parent"]=idx;
    
    NumericVector b (length_var);
    if(RightEx==1)
    {
      
      for(int i=0;i<length_var;i++)
      {
        if(i!=(Var-1))
        {
          b[i]=varavail_parent_l[i];
        }else{
          b[i]=0;
        }
      }
      
    }else{
      
      for(int i=0;i<length_var;i++)
      {
        
        b[i]=varavail_parent_l[i];
        
      }
    }
    
    rightchild["VarAvail"]=b;
    //as<List>(as<List>(as<List>(tree[treeI-1])[concatenate(node_idx_r)]))["VarAvail"]=b;
    
    
    // set data
    datalist=tree_curr["DataList"];
    for (int i=0; i<datalist.length();i++)
    {
      SetDataC(treeI,idx,datalist[i],Var,Rule,VarType,tree,x,RuleNum,Rulemat);
    }
      
    
    
}  

// // [[Rcpp::export]]
// int DepthC(Rcpp::List tree, int treeI, int idx)
// {
//   int d=0;
//   Rcpp::List tree_curr=tree_access(treeI,idx,tree);
//   
//   int stp=0;
//   while(stp==0)
//   {
//     Rcpp::List tree_curr=tree_access(treeI,idx,tree);
//     
//     if(!tree_curr["Top"])
//     {
//       d=d+1;
//       idx=tree_curr["Parent"];
//     }else{
//       stp=1;
//     }
// 
//   }
//   
//   return(d);
// }
// 
// 
// // [[Rcpp::export]]
// double PGrowC(Rcpp::List tree, int treeI, int idx)
// {
//   double result;
//   double alpha=0.95;
//   double beta=2.0;
//   
//   Rcpp::List tree_curr=tree_access(treeI,idx,tree);
//   NumericVector var=tree_curr["VarAvail"];
//   int SumGoodVar=sum(var);
//   
//   if(SumGoodVar)
//   {
//     NumericVector datalist=tree_curr["DataList"];
//     int nobs=datalist.length();
//     
//     if(nobs<3) {
//       
//       result=(.001*alpha)/pow((1.0+DepthC(tree,treeI,idx)),beta);
//       
//     }else {
//       
//       result=alpha/pow((1.0+DepthC(tree,treeI,idx)),beta);
//     }
//   } else {
//     
//     result=0.0;
//   }
//   
//   return(result);
// }
// 
  
  
  
  
  
