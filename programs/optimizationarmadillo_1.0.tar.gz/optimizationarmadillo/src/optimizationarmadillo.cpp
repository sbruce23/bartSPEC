#include <cmath>
#include <cstddef>
#include <algorithm>

#include <RcppArmadillo.h>
#include <RcppArmadilloExtensions/sample.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>

#include <boost/math/tools/roots.hpp>


//[[Rcpp::depends(BH)]]
//[[Rcpp::depends(RcppArmadillo)]]

namespace tools = boost::math::tools;
using namespace Rcpp;
using namespace arma;



arma::mat matrix_big_mat(arma::mat a, arma::mat b)
{
  arma::mat out=arma::zeros<arma::mat>(a.n_rows,b.n_rows*b.n_cols);
  int i,j,k;
  
  
  for(i=0;i<a.n_rows;i++)
  {
    for(j=0;j<a.n_cols;j++)
    {
      for(k=0;k<a.n_cols;k++)
      {
        
        out(i,(j*a.n_cols+k))=a(i,j);
        
      }
    }
  }
  
  return(out);
}


//[[Rcpp::export]]
Rcpp::List whittle_derivs2_RA(arma::vec x, int n, arma::mat nu_mat, arma::mat ytemp,double tau_temp,int nbeta,int nbasis,double sigmasqalpha)
{
  double f;
  arma::mat param(x);
  
  arma::mat ydev=ytemp-repmat(nu_mat*param,1,ytemp.n_cols);
  
  
  int n1=std::floor(n/2);
  int mod=n-n1*2;

  if (mod==1)
  {
     arma::mat pro=(param.rows(1,nbeta-1).t()*param.rows(1,nbeta-1))/tau_temp+pow(param(0,0),2)/sigmasqalpha;
     arma::mat sym=nu_mat.row(0)*param;
     f=sum(sum(repmat(nu_mat.rows(1,n1)*param,1,ytemp.n_cols)+exp(ydev.rows(1,n1))))+
       0.5*(sum(sym(0,0)+exp(ydev.row(0))))+
       0.5*pro(0,0);

  }else
  {
    arma::mat pro=(param.rows(1,nbeta-1).t()*param.rows(1,nbeta-1))/tau_temp+pow(param(0,0),2)/sigmasqalpha;
    arma::mat sym=nu_mat.row(0)*param;
    arma::mat sym_one=nu_mat.row(n1)*param;
    f=sum(sum(repmat(nu_mat.rows(1,n1-1)*param,1,ytemp.n_cols)+exp(ydev.rows(1,n1-1))))+
      0.5*(sum(sym(0,0)+exp(ydev.row(0))))+
      0.5*(sum(sym_one(0,0)+exp(ydev.row(n1))))+
      0.5*pro(0,0);
  }
  


  arma::mat temp_mat;
  arma::vec gr = arma::zeros<arma::vec>(x.n_elem);

  gr(0)=param(0,0)/sigmasqalpha;
  gr.subvec(1,nbeta-1)=param.rows(1,nbeta-1)/tau_temp;


  if(mod==1)
  {

    for (int i=0;i<ytemp.n_cols; i++)
    {
      temp_mat=nu_mat.rows(1,n1)%repmat((1-exp(ydev(span(1,n1),i))),1,nu_mat.n_cols);
      gr=gr+sum(temp_mat,0).t()+(0.5*(1-exp(ydev(0,i)))*nu_mat.row(0)).t();
    }


  }else
  {
    for (int i=0;i<ytemp.n_cols; i++)
    {
      temp_mat=nu_mat.rows(1,n1-1)%repmat((1-exp(ydev(span(1,n1-1),i))),1,nu_mat.n_cols);
      gr=gr+sum(temp_mat,0).t()+(0.5*(1-exp(ydev(0,i)))*nu_mat.row(0)).t()+
        (0.5*(1-exp(ydev(n1,i)))*nu_mat.row(n1)).t();
    }

  }


  arma::mat he = arma::zeros<arma::mat>(nbeta, nbeta);
  he(0,0)=1.0/sigmasqalpha;
  he.submat(1,1,nbeta-1,nbeta-1)=(1.0/tau_temp)*(arma::eye(nbasis,nbasis));

  arma::mat jj=arma::linspace(1,nbeta,nbeta).t();
  arma::mat coef_mat;
  arma::mat big_mat;


 if(mod==1)
 {

    big_mat=repmat(nu_mat.rows(1,n1).t(),nbeta,1) % (matrix_big_mat(nu_mat.rows(1,n1),repmat(jj,nbeta,1)).t());

    for (int i=0;i<ytemp.n_cols; i++)
    {
      coef_mat=repmat(exp(ydev(span(1,n1),i).t()),pow(nbeta,2),1);

      arma::mat temp=big_mat % coef_mat;
      arma::cube c(nbeta, nbeta, n1);

      int jj=0;

      for(int z=0;z<c.n_slices;z++)
      {
        for(int j=0;j<c.n_cols;j++)
        {
          for(int q=0;q<c.n_rows;q++)
          {
            c(q,j,z)=temp(jj);
            jj=jj+1;

          }
        }
      }

      arma::mat sum_mat=sum(c,2);
      he=he+sum_mat+(0.5*exp(ydev(0,i))*nu_mat.row(0)).t() * nu_mat.row(0);

    }


  }else
  {

    big_mat=repmat((nu_mat.rows(1,n1-1)).t(),nbeta,1) % (matrix_big_mat(nu_mat.rows(1,n1-1),repmat(jj,nbeta,1)).t());
    for (int i=0;i<ytemp.n_cols; i++)
    {
      coef_mat=repmat(exp(ydev(span(1,n1-1),i).t()),pow(nbeta,2),1);

      arma::mat temp_one=big_mat % coef_mat;
      arma::cube c_one(nbeta, nbeta, n1-1);

      int jj=0;

      for(int z=0;z<c_one.n_slices;z++)
      {
        for(int j=0;j<c_one.n_cols;j++)
        {
          for(int q=0;q<c_one.n_rows;q++)
          {
            c_one(q,j,z)=temp_one(jj);
            jj=jj+1;

          }

        }
      }


      arma::mat sum_mat_one=sum(c_one,2);
      he=he+sum_mat_one+
        (0.5*exp(ydev(0,i))*nu_mat.row(0)).t() * nu_mat.row(0)+
        (0.5*exp(ydev(n1,i))*nu_mat.row(n1)).t() * nu_mat.row(n1);
    }
    

 }

 Rcpp::List re =List::create(Named("value",0), _["gradient"]=0, _["hessian"]=0);

 re[0]=f;
 re[1]=gr;
 re[2]=he;

 return(re);
  
}



arma::mat eigenVector(arma::mat M) {
  
  arma::vec eval;
  arma::mat evec;
  arma::eig_sym(eval,evec,M);
  return evec;
}


arma::vec eigenValue(arma::mat M) {
  
  arma::vec eval;
  arma::mat evec;
  arma::eig_sym(eval,evec,M);
  return eval;
}


double norm(arma::vec x)
{
  
  arma::vec m=x%x;
  
  return sqrt(sum(m));
}



arma::mat rcpparma_outerproduct(arma::vec x) {
  arma::mat m = x * x.t();
  return m;
}


double C2=1.0;
double C1=1.0;
int r=1;
arma::vec gq;
arma::vec trust_beta;



double fredC(double beep)
{
  double result;
  
  if(beep==0)
  {
    if(C2>0)
    {
      result= -1.0/r;
      
    }else{
      
      result=sqrt(1.0 / C1) - 1.0 / r;
    }
    
  }else{
    
    result=sqrt(1.0 / sum(pow((gq / (trust_beta + beep)), 2))) - 1.0 / r;
  }
  
  return result;
}




bool root_termination(double min, double max) {
  return abs(max - min) <= 0.000001;
}


// [[Rcpp::export]]
Rcpp::List trust_RA(arma::vec parinit, double rinit, double rmax, arma::vec parscale, int iterlim, double fterm, double mterm, bool minimize, int n, arma::mat nu_mat, arma::mat ytemp, double tau_temp,int nbeta,int nbasis, double sigmasqalpha)
{
  
  double r=rinit;
  
  Rcpp::List out=whittle_derivs2_RA(parinit,n, nu_mat, ytemp, tau_temp, nbeta, nbasis, sigmasqalpha);
  arma::vec theta=parinit;
  
  bool accept=true;
  bool rescale=true;
  int iiter;
  double f=0.0;
  arma::vec g;
  arma::mat B;
  NumericMatrix B_mat;
  NumericVector g_vec;
  arma::mat Eivector;
  arma::vec Eivalue;
  arma::vec ptry;
  arma::vec wtry;
  arma::vec utry;
  arma::vec vtry;
  arma::vec theta_try;
  double C3=0.0;
  bool is_terminate;
  bool is_hard;
  bool is_easy;
  bool is_newton;
  double rho=0.0;
  
  
  for(iiter=0;iiter<iterlim;iiter++)
  {
    
    
    
    if(accept)
    {
      // output B
      NumericVector B_vec=out["hessian"];
      B_vec.attr("dim") = Dimension(nbeta, nbeta);
      B_mat=as<NumericMatrix>(B_vec);
      B=as<arma::mat>(B_mat);
      
      // output g
      g_vec=out["gradient"];
      g=as<arma::vec>(g_vec);
      
      // output f
      f=out["value"];
      
      if(rescale)
      {
        B=B/rcpparma_outerproduct(parscale);
        g=g/parscale;
      }
      
      if (!minimize) {
        
        B=-B;
        g=-g;
        f=-f;
        
      }
      
      
      Eivector=eigenVector(B);
      Eivalue=eigenValue(B);
      
      gq=Eivector.t()*g;
      

    }
    
    // solve trust region subproblem 
    // try for Newton 
    is_newton=FALSE;
    if (all(Eivalue>0))
    {
      
      ptry=-(Eivector*(gq/Eivalue));
      
      
      if(norm(ptry)<=r)
      {
        is_newton=TRUE;
      }
      
      
    }
    

    // non-Newton
    if(!is_newton)
    {
      
      
      double lambda_min=min(Eivalue);
      
      trust_beta=Eivalue-lambda_min;
      
      
      arma::uvec inotmin= find(trust_beta!=0);
      arma::uvec imin= find(trust_beta==0);
      
      arma::vec ratio=gq/trust_beta;
      
      C1=sum(pow(ratio(inotmin),2));
      C2=sum(pow(gq(imin),2));
      arma::vec temp=sum(pow(gq,2));
      C3=temp(0);
      
      
      
      if( (C2>0) || (C1>pow(r,2)) )
      {
        
        
        is_easy= TRUE;
        is_hard= (C2==0);
        // easy cases
        double beta_dn=std::sqrt(C2)/r;
        double beta_up=std::sqrt(C3)/r;
        
        
        double uout;
        if(fredC(beta_up)<=0)
        {
          uout=beta_up;
          
        }else if(fredC(beta_dn)>=0)
        {
          uout=beta_dn;
          
        }else{
          
          std::pair<double, double> result = tools::bisect(fredC, beta_dn, beta_up, root_termination);
          uout = (result.first + result.second)/2.0;
          
          
        }
        
        wtry=gq/(trust_beta+uout);
        ptry=-Eivector*wtry;
        
        
        
      }else{
        
        is_hard=TRUE;
        is_easy=FALSE;
        
        // hard-hard case
        wtry=gq/trust_beta;
        wtry.elem(imin).fill(0);
        ptry= -Eivector*wtry;
        utry=sqrt(pow(r,2)-sum(pow(ptry,2)));
        
        if(utry(0)>0){
          
          vtry=Eivector.col(imin(0));
          ptry=ptry+utry*vtry;
          
        }
      }
      
    }
    
    
    
    // predicted versus actual change
    double preddiff = sum(ptry % (g + (B * ptry) / 2));
    
    if (rescale) {
      theta_try = theta + ptry / parscale;
    } else {
      theta_try = theta + ptry;
    }
    
   
    out=whittle_derivs2_RA(theta_try,n, nu_mat, ytemp, tau_temp, nbeta, nbasis, sigmasqalpha);
    double ftry=out["value"];
    
    
    if (! minimize)
    {
      ftry = (- ftry);
    }
    
    rho = (ftry - f) / preddiff;
    
    
    // termination test
    if (ftry < arma::math::inf()) {
      is_terminate = (abs(ftry - f) < fterm) || (abs(preddiff) < mterm);
    } else {
      is_terminate = FALSE;
      rho = (-1* arma::math::inf());
    }
    
    //adjustments
    if (is_terminate) {
      if (ftry < f) {
        accept = TRUE;
        theta = theta_try;
      }
    } else {
      
      
      if (rho <  (1.0 / 4)) {
        accept = FALSE;
        r = r / 4.0;
      } else {
        accept = TRUE;
        theta = theta_try;
        if (rho > (3.0 / 4) && (! is_newton))
        {
          r = std::min(2*r, rmax);
        }
        
      }
      
    }
    
    if (is_terminate)
    {
      break;
    }
    
    
  }
  

  Rcpp::List out_re=whittle_derivs2_RA(theta, n, nu_mat, ytemp, tau_temp, nbeta, nbasis, sigmasqalpha);
  
  Rcpp::List re =List::create(Named("value",0), _["gradient"]=0, _["hessian"]=0,_["argument"]=0,_["converged"]=0, _["iterations"]=0);
  
  re[0]=out_re[0];
  re[1]=out_re[1];
  re[2]=out_re[2];
  re[3]=theta;
  re[4]=is_terminate;
  re[5]=iiter+1;
  
  
  return(re);
  
  
}



String concatenate(StringVector a)
{
  String c;
  std::ostringstream x;
  
  // concatenate inputs
  for (int i = 0; i < a.size(); i++)
    x << a[i];
  
  c.push_back(x.str());
  
  return c;
  
}


Rcpp::List tree_access(int treeI, int idx, Rcpp::List tree)
{
  Rcpp::StringVector node_idx(2);
  node_idx[0]="node";
  node_idx[1]=idx;
  
  
  Rcpp::List tr=as<List>(as<List>(tree[treeI-1])[concatenate(node_idx)]);
  return(tr);
}










